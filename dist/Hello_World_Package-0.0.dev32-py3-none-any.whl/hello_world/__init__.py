# -*- coding: utf-8 -*-
from __future__ import print_function
from ._version import get_versions

__author__ = 'Mike Mitterer'
__email__ = 'mike@MangoLila.at'
__version__ = get_versions()['version']

del get_versions

