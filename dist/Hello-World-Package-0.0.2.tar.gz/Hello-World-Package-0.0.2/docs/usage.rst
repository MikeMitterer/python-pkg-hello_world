========
Usage
========

To use Hello World Package in a project::

    import hello_world
